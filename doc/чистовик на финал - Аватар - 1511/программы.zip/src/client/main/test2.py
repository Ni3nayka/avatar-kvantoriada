from time import sleep

print("Hacking your PC")

for i in range (11):
	print("Hacking -", i*10,"%")
	sleep(1+i/5)

print("Hacking is successfull")
print("Thanks :)")